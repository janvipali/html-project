const users = [
    { username: "mohammad", password: "pass" },
    { username: "rafi", password: "pass2" }
];

document.getElementById('login-form').addEventListener('submit', function (e) {
    e.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const user = users.find(user => user.username === username && user.password === password);

    if (user) {
        document.getElementById('login-section').style.display = 'none';
        document.getElementById('shop-section').style.display = 'block';
    } else {
        document.getElementById('login-message').textContent = 'Invalid username or password';
    }
});

document.querySelectorAll('.purchase-button').forEach(button => {
    button.addEventListener('click', function () {
        const productName = this.parentElement.querySelector('h3').textContent;
        window.location.href = `confirmation.html?product=${encodeURIComponent(productName)}`;
    });
});
